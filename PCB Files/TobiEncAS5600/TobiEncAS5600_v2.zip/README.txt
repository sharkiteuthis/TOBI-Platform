Bottom Copper		GBL
Bottom Silkscreen	GBO
Bottom Soldermask	GBS
Top Copper		GTL
Top Silkscreen		GTO
Top Soldermask		GTS
Drill File		TXT
Drill Station Info File	dri
Photoplotter Info File	gpi
Mill Layer		GML
Top Paste		GTP

Bill of Materials	XLSX
Centroid File		CSV
